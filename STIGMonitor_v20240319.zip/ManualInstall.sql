/******** ONLY USE THIS IF POWERSHELL GUI INSTALL DOES NOT WORK  **********************
** Must be executed using SQLCmd or with SSMS in SqlCmd Mode **************************
STEPS:
   1) BACKUP THE ORIGINAL STIGMonitor DB
   2) DROP ALL TABLES IN TEMPDB like: dbo.TEMP_STIG_*
            BEGIN TRY DROP TABLE [tempdb].[dbo].[TEMP_STIG_INSTANCE]       END TRY BEGIN CATCH END CATCH
            BEGIN TRY DROP TABLE [tempdb].[dbo].[TEMP_STIG_ConfigSettings] END TRY BEGIN CATCH END CATCH
            BEGIN TRY DROP TABLE [tempdb].[dbo].[TEMP_STIG_FINDING]        END TRY BEGIN CATCH END CATCH
            BEGIN TRY DROP TABLE [tempdb].[dbo].[TEMP_STIG_POLICYHISTORY]  END TRY BEGIN CATCH END CATCH
            BEGIN TRY DROP TABLE [tempdb].[dbo].[TEMP_STIG_CMSFINDING]     END TRY BEGIN CATCH END CATCH
   3) Export the data from the old STIGMonitor DB
      EXEC STIG.usp_sysMigrateData  @Stage = 'PreMigration'
   4) Using SSMS > IMPORT DATA TIER APPLICATION
   5) Select the STIGMonitor.BACPAC to import (name DB as appropriate needs to match variable defined below)
   6) SET Query to execute as SQLCMS (Menu > Query > SQLCMD Mode)
   7) Fill in the SQLCMD Variables listed below
   8) Execute script in SQLCMD Mode
   9) Review output and request a new STIGMonitor License using the information in the output
      Cut and paste the output after: 
      Send the following information to STIGMonitor@Microsoft.com
   10) Copy/Rename the STIGMonitor.BACPAC to STIGMonitor.ZIP
   11) Open ZIP File and extract (copy/paste) ALL the Folders and files under the .\Deploy folder
       Into the Install Path  location (defined below)
       Should be these folders: Hardening and Maintenance, Reports, Scripts and ALL Files
***************************************************************************************/

SET NOEXEC OFF;--Set these parameters prior to running.
SET NOCOUNT ON;
:setvar InstallPath          "C:\MSSQL\StigMonitor\" --Edit the path for the STIGMonitor Files
:setvar CMSGroup             "<CMS_GroupName>"       --Edit the name of your Top Level CMS Group
:setvar PolicyServer         "<YourCMSServerName>"   --Edit name of SQLL Instance that you are installing this to
:setvar DataWarehouseName    "STIGMonitor"           --Edit the name database for STIGMonitor (Default: STIGMonitor)
:setvar IsLocal_1_or_0       "0"                     --If using CMS=0 / If this is just a LocalCopy=1
:setvar CustomerName         "<YourOrgName>"         --Edit the name of Organization
:setvar CustomerEmail        "<user@mail.mil>"       --Edit the Email Address for the customer
:setvar NumberOfSQLInstances 100                     --Sets the number of instances you plan to use STIGMonitor for
/***************************************************************************************
** Must be executed using SQLCmd or with SSMS in SqlCmd Mode **************************
***************************************************************************************/
/*
Detect SQLCMD mode and disable script execution if SQLCMD mode is not supported.
To re-enable the script after enabling SQLCMD mode, execute the following:
SET NOEXEC OFF;

  Copyright (C) 2017 Microsoft Corporation
  Disclaimer:
        This is SAMPLE code that is NOT production ready. It is the sole intention of this code to provide a proof of concept as a
        learning tool for Microsoft Customers. Microsoft does not provide warranty for or guarantee any portion of this code
        and is NOT responsible for any affects it may have on any system it is executed on or environment it resides within.
        Please use this code at your own discretion!
  Additional legalize:
        This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.
    THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
    INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
    We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to reproduce and distribute
    the object code form of the Sample Code, provided that You agree:
                  (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded;
         (ii) to include a valid copyright notice on Your software product in which the Sample Code is embedded; and
         (iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys� fees,
               that arise or result from the use or distribution of the Sample Code.
*/
:setvar __IsSqlCmdEnabled "True"
GO
IF N'$(__IsSqlCmdEnabled)' NOT LIKE N'True'
    BEGIN
        PRINT N'SQLCMD mode must be enabled to successfully execute this script.';
        SET NOEXEC ON;
    END
GO

IF OBJECT_ID('TempDB.dbo.SQLCMDParameters') IS NULL
BEGIN
CREATE TABLE TEMPDB.dbo.SQLCMDParameters(
        Setvar   varchar(50) NOT NULL,
        CMDValue varchar(255) NULL,
 CONSTRAINT PK_SQLCMDParameters PRIMARY KEY CLUSTERED (Setvar ASC)) ON [PRIMARY]
END

BEGIN TRY
   INSERT INTO TEMPDB..SQLCMDParameters
   SELECT 'InstallPath              ','$(InstallPath)'            UNION
   SELECT 'CMSGroup                 ','$(CMSGroup)'               UNION
   SELECT 'PolicyServer             ','$(PolicyServer)'           UNION
   SELECT 'DataWarehouseName        ','$(DataWarehouseName)'      UNION
   SELECT 'IsLocal_1_or_0           ','$(IsLocal_1_or_0)'         UNION
   SELECT 'CustomerName             ','$(CustomerName)'           UNION
   SELECT 'CustomerEmail            ','$(CustomerEmail)'          UNION
   SELECT 'NumberOfSQLInstances     ','$(NumberOfSQLInstances)'   UNION 
   SELECT * FROM TEMPDB.dbo.SQLCMDParameters
   EXCEPT
   SELECT Setvar,CMDValue
   FROM  TEMPDB.dbo.SQLCMDParameters
   Order by 1
END TRY
BEGIN CATCH
   IF @@Error  = 2627
   RAISERROR('You have entered different parameters for the same SQLCMD variable, check the Error message for the duplicate value',16,1) WITH NOWAIT

   SELECT 'InstallPath              ','$(InstallPath)'            UNION
   SELECT 'CMSGroup                 ','$(CMSGroup)'               UNION
   SELECT 'PolicyServer             ','$(PolicyServer)'           UNION
   SELECT 'DataWarehouseName        ','$(DataWarehouseName)'      UNION
   SELECT 'IsLocal_1_or_0           ','$(IsLocal_1_or_0)'         UNION
   SELECT 'CustomerName             ','$(CustomerName)'           UNION
   SELECT 'CustomerEmail            ','$(CustomerEmail)'          UNION
   SELECT 'NumberOfSQLInstances     ','$(NumberOfSQLInstances)'   UNION 
   SELECT * FROM TEMPDB.dbo.SQLCMDParameters
   ORDER BY 1

   SET NOEXEC ON;

END CATCH

SELECT * FROM TEMPDB.dbo.SQLCMDParameters
Order by 1
Print '# Configure the synonyms on this instance'
Print '   > Creating synonyms'
    EXEC STIG.usp_sysBuildSynonym

Print '   > Updating configuration parameters'
   EXEC STIG.usp_sysSetConfigParameters

Print '   > Generate the CMS Function'
    EXEC STIG.usp_sysCreateCMSFunction

Print 'Registering configuration options...'
USE [$(DataWarehouseName)]
UPDATE STIG.ConfigParameter SET ParameterValue = '$(InstallPath)'          WHERE ParameterName = 'PowerShellPath';
UPDATE STIG.ConfigParameter SET ParameterValue = '$(CMSGroup)'             WHERE ParameterName = 'CMSGroup';
UPDATE STIG.ConfigParameter SET ParameterValue = '$(PolicyServer)'         WHERE ParameterName = 'CMSServer';
UPDATE STIG.ConfigParameter SET ParameterValue = '$(DataWarehouseName)'    WHERE ParameterName = 'DWNames';
UPDATE STIG.ConfigParameter SET ParameterValue = '$(IsLocal_1_or_0)'       WHERE ParameterName = 'IsLocal';
UPDATE STIG.ConfigParameter SET ParameterValue = '$(CustomerName)'         WHERE ParameterName = 'LicenseUser';
UPDATE STIG.ConfigParameter SET ParameterValue = '$(CustomerEmail)'        WHERE ParameterName = 'CustomerEmail';
UPDATE STIG.ConfigParameter SET ParameterValue = '$(NumberOfSQLInstances)' WHERE ParameterName = 'NumberOfSQLServers';

Print '# Create the SQL Agent Proxy account'
Print '   > Creating Proxy'
   EXEC STIG.usp_sysCreateProxy

Print '# Create the initial SQL Agent job for checking compliance'
Print '   > Creating SQL Agent job'
    EXEC STIG.usp_sysBuildSQLAgentJob

Print '   > STIG.usp_sysMigrateData' 
EXEC STIG.usp_sysMigrateData  @Stage = 'PostMigration', @Debug = 0

Print '# Create LicenseKey Challenge value'
Print '   > Activate License'
    EXEC STIG.ActivateLicense
