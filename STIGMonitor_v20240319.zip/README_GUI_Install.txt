<## STIG Monitor v2019-10-19 #################################################################
Author: Daniel Mellor (PFE) 
Date: 2018-09-06
History:

Date           Name                    Comment
-----------    ---------------------   ------------------------------------------------------
07 May 2019    Adrian Rupp (MSFT)      BETA Build of GUI installer
30 May 2019    Adrian Rupp (MSFT)      Change installation message / new build for 5/30/2019 remove trigger
08 Aug 2019    Adrian Rupp (MSFT)      Build with new DISA STIGs for 26 July 2019
19 Aug 2019    Adrian Rupp (MSFT)      Updated GUI install and removed DISA objects
---------------------------------------------------------------------------------------------

##############################################################################################
Questions, Comments, Feedback, Bugs, Issues please feel free to contact:
   Daniel Mellor (PFE)   : daniel.mellor@microsoft.com
   Patrick Keisler (PFE) : pkeisler@microsoft.com
   Brandon Adams (PFE)   : bradams@microsoft.com
   Adrian Rupp (MCS)     : arupp@microsoft.com
##############################################################################################>

<## Quick Start guide to SQL 2016 STIG Monitor Solution.

Installation note: 
Open PowerShell as Administrator:
Navigate to the Installation Path:
Run Install-StigMonitorGUI.ps1 script to start GUI
Fill in GUI text boxes Click INSTALL.

## Review the data in the STIG.ConfigParameter table for additional (dynamic) settings.

## Note:
   You will also need to reset the Password for the STIG_Cred (credential) 
   that is used in the STIG_Proxy (assigned to the SQL Agent Job) if this is a fresh new install

## License Key:
   For full feature functionality, you will need to obtain a FREE Lincese Key from STIGMonitor Support:
   At the end of the PowerShell installation scrip you will see Yellow and Green text:

Log into https://aka.ms/STIGMonitor to self-generte a License Key < Do this first to request a License Key.
If the above website is down for any reason, you can alternatively 
send the following information (in yellow and green text) to STIGMonitor@Microsoft.com
Customer/Org Name      : User Name For License <<<
License Key Challenge  : 123456789 ^^^
Encryption Key Value   : 987654321 >>>
Customer Email Address : user@mail.mil
Number of SQL Instances: 10
You will receive a FREE License Key and instructions for full functionality.

   If you e-mail this information to STIGMonitor@Microsoft.com
   STIGMonitor support team will send you instructions to activate your license.
   Without a license Key, you can still use STIGMonitor but only for a single SQL Instance.

## Extras:
   PowerShell deployment copies files to your installation location in respective folders:
   - Save Reports to a folder accessable by SSMS Custom Reports (New reports for older SSMS (<2014) available on request
   - Save Hardening and Maintenance (script for Maintenance Plans, encryption, DBMail, hardening, etc)
   - Save Scripts (additional scripts to setup auditing, FileStream, Audit Offload, etc)
   - Save Supplement (STIG info and STIG Viewer from DISA)

## Get the latest STIGs here:
https://public.cyber.mil/stigs/downloads/
## If you have questions you can send a message to STIGMonitor Support at: STIGMonitor@Microsoft.com ## 