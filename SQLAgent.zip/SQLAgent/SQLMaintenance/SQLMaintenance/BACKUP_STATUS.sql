SET NOCOUNT ON;
declare @t table(db sysname, val nvarchar(128))
declare @tt table(po nvarchar(128), obj nvarchar(128),Field nvarchar(128), val nvarchar(128))
insert @t(db)
select name from sys.databases where database_id<>2
DECLARE @Name VARCHAR(255);

DECLARE looping_cursor CURSOR
FOR 
SELECT db
FROM @t

OPEN looping_cursor
FETCH NEXT FROM looping_cursor INTO @Name
WHILE @@FETCH_STATUS = 0
    BEGIN
	
insert @tt
exec ('DBCC DBINFO ('''+@Name+''')WITH TABLERESULTS, NO_INFOMSGS')
update @t 
set val = tt.val
FROM @tt tt where db = @Name and Field in( 'dbi_dbccLastKnownGood');
delete @tt
FETCH NEXT FROM looping_cursor INTO @Name
    END
CLOSE looping_cursor;
DEALLOCATE looping_cursor;
--select * from @t ;

WITH BackupSet AS
(
	SELECT dbid,
	  ISNULL([D],'1900-01-01') [D], ISNULL([I],'1900-01-01') I, ISNULL([L],'1900-01-01') [L]  
	FROM  
	(  SELECT [type]
		, Max(backup_finish_date) backup_finish_date
		,[dbid]
		  from sys.sysdatabases d
		LEFT JOIN msdb..backupset bs on d.name = bs.database_name 
		WHERE dbid<>2
		GROUP BY [type],[dbid]
	) AS SourceTable  
	PIVOT  
	(  
	  Max(backup_finish_date)  
	  FOR [Type] IN ([D], [I], [L])  
	) AS PivotTable 
)

SELECT b.*
	,d.name
	,BadOwner =  case owner_sid when 0x01 then 0 else 1 end 
	,[Owner] = suser_sname(owner_sid)
	,MissingFullBackup = CASE WHEN DATEDIFF(DD, [D],GETDATE())<=7 THEN 0 WHEN sys.fn_hadr_backup_is_preferred_replica(d.name)=0 THEN 0 ELSE 1 END
	,MissingDiffBackup = CASE WHEN (DATEDIFF(hh, [I],GETDATE())<=24 OR (DATEPART(DW,getdate())=2 AND DATEDIFF(hh, [I],GETDATE())<48 ) OR d.database_id<=4) THEN 0 WHEN sys.fn_hadr_backup_is_preferred_replica(d.name)=0 THEN 0  ELSE 1 END
	,MissingLogBackup = CASE WHEN DATEDIFF(MI, [L],GETDATE())<=1 OR d.database_id<=120 OR recovery_model = 3 THEN 0 WHEN sys.fn_hadr_backup_is_preferred_replica(d.name)=0 THEN 0  ELSE 1 END
	,d.recovery_model_desc
	,CollectionDate = GETUTCDATE()
	,ServerName = @@SERVERNAME 
	,LastGoodCheckDbTime = t.val--CAST(DATABASEPROPERTYEX(name,'LastGoodCheckDbTime') AS datetime)
	,[Version] = substring(@@VERSION,22,4)
	,[Build] = substring(@@VERSION,28,3) 
	,Edition = CAST(SERVERPROPERTY('Edition') AS VARCHAR(50))
	,ProductLevel = CASE CHARINDEX('CU',@@VERSION,1) WHEN 0 THEN NULL ELSE substring(@@VERSION,CHARINDEX('CU1',@@VERSION,1),4) END
	,SQLAgentStatus = CASE WHEN d.name='msdb' THEN ISNULL((select TOP(1) 1 FROM MASTER.dbo.sysprocesses WHERE program_name like N'SQLAgent%'),0)^1 ELSE 0 END
	,d.state_desc
	,DB_State = CASE d.state WHEN 0 THEN 0 ELSE 1 END
FROM  sys.databases d
LEFT JOIN BackupSet b (nolock) on d.database_id = b.dbid
JOIN @t t on t.db = d.name
WHERE dbid<>2;