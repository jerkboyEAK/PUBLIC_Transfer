SET NOCOUNT ON;
WITH Details as
(
SELECT [Job] = j.name
      ,ServerName = @@SERVERNAME
	  ,Missing = CASE WHEN j.name is null THEN 1 ELSE 0 END
      ,[run_date] = msdb.dbo.agent_datetime(h.run_date,h.run_time)
     ,[next_run_date] = msdb.dbo.agent_datetime(nullif(js.next_run_date,0), nullif(js.next_run_time,0))
      ,[JobOwner] = suser_sname(j.owner_sid)
	  ,[Job Status] = h.run_status
      ,[run_duration] = h.run_duration
      ,[IsJobDisabled] =  j.[Enabled]^1 
      ,[IsScheduleDisabled] = s.[enabled]^1
      ,[IsScheduleInActive] = CASE WHEN s.active_start_date<s.active_end_date THEN 0 ELSE 1 END
	  ,ROW_NUMBER ( ) OVER (PARTITION BY j.name ORDER BY h.run_date DESC, h.run_time desc) RN
	  FROM msdb..sysjobs j 
	  LEFT JOIN msdb..sysjobschedules js on js.job_id=j.job_id
	  LEFT JOIN msdb..sysschedules s on s.schedule_id = js.schedule_id
	  LEFT JOIN [msdb].[dbo].[sysjobhistory] h on j.job_id = h.job_id and step_id = 0
	  WHERE j.category_id = 3
  )

SELECT [CollectionDate] = getutcdate()
	,[Job]
      ,ServerName
      ,[Missing]
      ,[run_date]
      ,[next_run_date]
      ,[JobOwner]
	  ,[Job Failed] = CAST(CASE [Job Status] WHEN 0 THEN 1 ELSE 0 END as TINYINT)
      ,[Job Status]
      ,[run_duration]
      ,[Disabled] = [IsJobDisabled]
      ,ScheduleDisabled = ISNULL([IsScheduleDisabled],1)
      ,ScheduleInActive = ISNULL([IsScheduleInActive],1)
	  ,[Status] = CASE WHEN [Job Status] = 0 then 'Failed' WHEN [Job Status] = 1 then 'Succeeded' WHEN [Job Status] = 2 then 'Retry' WHEN [Job Status] = 3 then 'Canceled' WHEN [Job Status] = 4 then 'Retry' else 'Unknown' END
  FROM Details
  WHERE RN = 1
  GO