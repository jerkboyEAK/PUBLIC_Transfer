USE [msdb]
GO

/****** Object:  View [dba].[vw_GetJobDetails]    Script Date: 8/12/2022 7:51:44 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO

ALTER VIEW [dba].[vw_GetJobDetails]
AS
WITH Jobs AS (
  SELECT 'syspolicy_purge_history' Job
	UNION
  SELECT 'DatabaseBackup - USER_DATABASES - DIFF'
	UNION
  SELECT 'DatabaseBackup - USER_DATABASES - FULL'
	UNION
  SELECT 'sp_delete_backuphistory'
	UNION
  SELECT 'CommandLog Cleanup'
	UNION
  SELECT 'DatabaseIntegrityCheck - USER_DATABASES'
	UNION
  SELECT 'DatabaseBackup - SYSTEM_DATABASES - FULL'
	UNION
  SELECT 'DatabaseBackup - USER_DATABASES - LOG'
	UNION
  SELECT 'DatabaseIntegrityCheck - SYSTEM_DATABASES'
	UNION
  SELECT 'IndexOptimize - USER_DATABASES'
	UNION
  SELECT 'sp_purge_jobhistory'
	UNION
  SELECT 'Output File Cleanup'
  	UNION
  SELECT 'Monthly Extracts MCSC'
  )
,Details as
(
SELECT [Job] = Jobs.Job
      ,ServerName = @@SERVERNAME
	  ,Missing = CASE WHEN j.name is null THEN 1 ELSE 0 END
      ,[run_date] = msdb.dbo.agent_datetime(h.run_date,h.run_time)
     ,[next_run_date] = msdb.dbo.agent_datetime(nullif(js.next_run_date,0), nullif(js.next_run_time,0))
      ,[JobOwner] = suser_sname(j.owner_sid)
	  ,[Job Status] = h.run_status
      ,[run_duration] = h.run_duration
      ,[IsJobDisabled] =  j.[Enabled]^1 
      ,[IsScheduleDisabled] = s.[enabled]^1
      ,[IsScheduleInActive] = CASE WHEN s.active_start_date<s.active_end_date THEN 0 ELSE 1 END
      ,[freq_sub] = s.freq_interval+s.freq_recurrence_factor+s.freq_relative_interval+s.freq_subday_interval+s.freq_subday_type 
	  ,[freq_type] 
	  ,[freq_interval]
      ,[freq_subday_type] 
      ,[freq_subday_interval] 
      ,[freq_relative_interval] 
      ,[freq_recurrence_factor]
	  ,ROW_NUMBER ( ) OVER (PARTITION BY Jobs.Job ORDER BY h.run_date DESC, h.run_time desc) RN
	  FROM Jobs 
	  LEFT JOIN msdb..sysjobs j ON Jobs.Job = j.name
	  LEFT JOIN msdb..sysjobschedules js on js.job_id=j.job_id
	  LEFT JOIN msdb..sysschedules s on s.schedule_id = js.schedule_id
	  LEFT JOIN [msdb].[dbo].[sysjobhistory] h on j.job_id = h.job_id and step_id = 0
  )

SELECT [CollectionDate] = getutcdate()
	,[Job]
      ,ServerName
      ,[Missing]
      ,[run_date]
      ,[next_run_date]
      ,[JobOwner]
	  ,[Job Failed] = CAST(CASE [Job Status] WHEN 0 THEN 1 ELSE 0 END as TINYINT)
      ,[Job Status]
      ,[run_duration]
      ,[Disabled] = [IsJobDisabled]
      ,ScheduleDisabled = ISNULL([IsScheduleDisabled],1)
      ,ScheduleInActive = ISNULL([IsScheduleInActive],1)
      ,[freq_sub]
      ,[freq_type]
      ,[freq_interval]
      ,[freq_subday_type]
      ,[freq_subday_interval]
      ,[freq_relative_interval]
      ,[freq_recurrence_factor]
	  ,[Status] = CASE WHEN [Job Status] = 0 then 'Failed' WHEN [Job Status] = 1 then 'Succeeded' WHEN [Job Status] = 2 then 'Retry' WHEN [Job Status] = 3 then 'Canceled' WHEN [Job Status] = 4 then 'Retry' else 'Unknown' END
  FROM Details
  WHERE RN = 1

GO


