set nocount on;


IF EXISTS(
select 1
 from sys.server_audits a
 JOIN sys.server_audit_specifications s on s.audit_guid = a.audit_guid
 WHERE a.is_state_enabled=1 and s.is_state_enabled = 1 and a.name='STIG_COMPLIANT_SERVER_AUDIT'
 )
 SELECT CollectionDate=GETUTCDATE(), @@servername [Server],1
 ELSE SELECT CollectionDate=GETUTCDATE(), @@servername [Server],IsSTIG = 0
