USE [msdb]
GO

/****** Object:  View [dba].[vw_BackupStatus]    Script Date: 4/21/2022 3:12:39 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER   VIEW [dba].[vw_BackupStatus]
AS
WITH LogSpace
AS
(SELECT [Database], ServerName, [LogSizeMB], [LogUsed]
,LRN = row_number() OVER(Partition BY  ServerName, [Database] ORDER BY CollectionDate DESC)
FROM dba.LOGSPACE
)
, AUDITSTATUS
as
(
select CollectionDate, ServerName, name,is_state_enabled,IsSTIG
,RN=ROW_NUMBER() OVER(PARTITION BY ServerName, name ORDER BY CollectionDate DESC)
 from dba.AuditStatus )
SELECT [CollectionDate] = CONVERT(datetime, 
               SWITCHOFFSET(CONVERT(datetimeoffset, 
                                    a.[CollectionDate]), 
                            DATENAME(TzOffset, SYSDATETIMEOFFSET()))) 
      ,a.[Database]
      ,a.[BadOwner]
      ,[MissingFullBackup] = a.[MissingFullBackup] - isnull(ex.[MissingFullBackup],0)
      ,[MissingDiffBackup]= a.[MissingDiffBackup] - isnull(ex.[MissingDiffBackup],0)
      ,[MissingLogBackup]= a.[MissingLogBackup] - isnull(ex.[MissingLogBackup],0)
      ,a.[recovery_model_desc]
	  ,a.ServerName
	  ,[DBCC]= a.[MissingFullBackup] - isnull(ex.[MissingFullBackup],0)
	  ,a.LastGoodCheckDbTime
	  	,a.[Version]
		,a.[Build]
		,a.[ProductLevel]
		,LogSizeMB = round(l.LogSizeMB,2)
		,LogUsed = round(l.LogUsed,2)
		,a.[SQLAgentStatus]
		,state_desc
		,DB_State
		,[IsSTIG]= isnull([is_state_enabled]*[IsSTIG], 0)^1
FROM (
		SELECT ID, [dbid]
		,[D]
		,[I]
		,[L]
		,[Database]
		,[BadOwner]
		,[Owner]
		,[MissingFullBackup] 
		,[MissingDiffBackup]
		,[MissingLogBackup]
		,[recovery_model_desc]
		,ServerName
		,LastGoodCheckDbTime
		,[DBCC] = CASE WHEN DATEDIFF(dd,LastGoodCheckDbTime,CollectionDate)<7 THEN 0 ELSE 1 END
		,[Version]
		,[Build]
		,[Edition]
		,[ProductLevel]
		,CollectionDate
		,RN = ROW_NUMBER() OVER(PARTITION BY ServerName, [Database] ORDER BY CollectionDate DESC)
		,[SQLAgentStatus]
		,state_desc = isnull(state_desc,'Unavailable')
	,DB_State = isnull(DB_State,0)
	
FROM [dba].[BackupStatus]) a
LEFT JOIN LOGSPACE l on a.ServerName = l.ServerName and a.[Database]=l.[database] AND LRN = 1
LEFT JOIN [dba].[Exclusion_BackupStatus] ex on ex.ServerName = a.ServerName and a.[Database] = ex.[Database]
LEFT JOIN [AuditStatus] s
  ON s.ServerName = a.ServerName AND [name] = 'STIG_COMPLIANT_SERVER_AUDIT' and s.rn = 1
WHERE a.RN=1 
GO


