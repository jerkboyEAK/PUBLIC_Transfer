USE [msdb]
GO

/****** Object:  View [dba].[vw_DBSize]    Script Date: 4/13/2022 8:17:42 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



ALTER   VIEW [dba].[vw_DBSize]
AS
WITH DBSize
AS
(
SELECT [Server]
      ,[Database]
      ,[type_desc]
      ,[Size]
      ,[CollectionDate]
      ,[Free]
	  ,[Total]
	  ,[Used]
	  ,RN = ROW_NUMBER() OVER(partition by [Server],[Database],[type_desc] ORDER BY [CollectionDate] desc)
  FROM [dba].[DBSize]
  )
SELECT [Server]
      ,[Database]
      ,[type_desc]
      ,[Size]
      ,[CollectionDate] = CONVERT(datetime, 
               SWITCHOFFSET(CONVERT(datetimeoffset, 
                                    [CollectionDate]), 
                            DATENAME(TzOffset, SYSDATETIMEOFFSET()))) 
      ,[Free] 
	  ,[Total]
	  ,[Used]
FROM DBSize
WHERE RN = 1
GO


