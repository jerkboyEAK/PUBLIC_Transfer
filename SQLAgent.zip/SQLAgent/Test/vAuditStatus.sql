USE [msdb]
GO

/****** Object:  View [dba].[vAuditStatus]    Script Date: 4/21/2022 3:03:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER VIEW [dba].[vAuditStatus]
AS
WITH AUDITSTATUS
as
(
select CollectionDate, [Server], name,is_state_enabled,IsSTIG
,RN=ROW_NUMBER() OVER(PARTITION BY [Server], name ORDER BY CollectionDate DESC)
 from dba.AuditStatus )
SELECT a.[Server]
      ,[IsSTIG]= isnull([is_state_enabled]*[IsSTIG], 0)
  FROM dba.[Servers] a
  LEFT JOIN [AuditStatus] s
  ON s.[Server] = a.[Server] AND [name] = 'STIG_COMPLIANT_SERVER_AUDIT' and rn = 1
GO


