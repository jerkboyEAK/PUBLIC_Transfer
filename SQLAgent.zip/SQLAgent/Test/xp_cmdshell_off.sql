BEGIN
exec sp_configure 'xp_cmdshell',0
reconfigure
exec sp_configure 'show advanced options',0
reconfigure
END