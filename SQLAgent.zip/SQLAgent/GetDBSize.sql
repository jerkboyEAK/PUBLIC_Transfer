SET NOCOUNT ON;
DECLARE @db TABLE([Database] sysname) 
;WITh CTE
AS
(
select @@servername ServerName
,Host = serverproperty('ComputerNamePhysicalNetBIOS')
,Used =  CAST(max(CONVERT(FLOAT,total_bytes))/1073741824 AS DECIMAL(15,2)) - CAST(max(CONVERT(FLOAT,available_bytes) )/1073741824 AS DECIMAL(15,2))
,Total = CAST(max(CONVERT(FLOAT,total_bytes))/1073741824 AS DECIMAL(15,2))
,Free = CAST(max(CONVERT(FLOAT,available_bytes) )/1073741824 AS DECIMAL(15,2))
,os.volume_mount_point
from sys.master_files f
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) os
GROUP BY os.volume_mount_point
),
DBInfo
AS
(
select @@servername ServerName
, db_name(f.database_id) [Database]
,type_desc
, [Size]
,Host = CAST(serverproperty('ComputerNamePhysicalNetBIOS') AS NVARCHAR(60))
,os.volume_mount_point

from sys.master_files f
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) os
)
SELECT 
ServerName = db.ServerName

      , db.[Database]
, db.Host      ,[type_desc]
      ,db.[Size]
      ,[CollectionDate] = GETUTCDATE()
      ,[Used]
      ,[Total]
      ,[Free]
	,db.volume_mount_point
FROM DBInfo db
JOIN CTE f on db.ServerName = f.ServerName and db.[Host] = f.[Host] and db.volume_mount_point=f.volume_mount_point;
GO


