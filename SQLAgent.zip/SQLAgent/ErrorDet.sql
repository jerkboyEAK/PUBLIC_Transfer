SET NOCOUNT ON;
DECLARE @errorLog TABLE(LogDate DATETIME, ProcessInfo VARCHAR(64), [Text] VARCHAR(MAX));
INSERT INTO @errorLog
EXEC sp_readerrorlog 0,1,'Error: '
select @@servername,* from @errorLog where datediff(hh,LogDate,getdate())<2