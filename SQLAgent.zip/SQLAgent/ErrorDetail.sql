SET NOCOUNT ON;
DECLARE @errorLog1 TABLE(LogDate DATETIME, ProcessInfo VARCHAR(64), [Text] VARCHAR(MAX));
DECLARE @errorLog2 TABLE(LogDate DATETIME, ProcessInfo VARCHAR(64), [Text] VARCHAR(MAX));
INSERT INTO @errorLog1
EXEC sp_readerrorlog 0,1,'Error: '
INSERT INTO @errorLog2
EXEC sp_readerrorlog 0,1
SELECT @@servername,b.*
FROM @errorLog1 a, @errorLog2 b
where a.LogDate=b.LogDate
AND datediff(hh,a.LogDate,getdate())<2;
GO
