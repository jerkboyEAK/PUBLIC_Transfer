/****** SCHEMA FOR CMS Server ******/
declare @sql nvarchar(256) = 'CREATE SCHEMA dba'
IF NOT EXISTS(SELECT name from sys.schemas WHERE name='dba')
BEGIN
exec (@sql)
END
GO

--Object:  Table [dba].[JobHstory]  
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dba].[JobHistory]') AND type in (N'U'))
CREATE TABLE [dba].[JobHistory](
	[CollectionDate] [datetime] NULL,
	[Job] [sysname] NOT NULL,
	[Server] [sysname] NULL,
	[Missing] [tinyint] NOT NULL,
	[run_date] [datetime] NULL,
	[next_run_date] [datetime] NULL,
	[JobOwner] [nvarchar](128) NULL,
	[Job Failed] [tinyint] NOT NULL,
	[Job Status] [int] NULL,
	[run_duration] INT NULL,
	[Disabled] [tinyint] NULL,
	[ScheduleDisabled] [tinyint] NULL,
	[ScheduleInActive] [tinyint] NULL,
	[freq_sub] [int] NULL,
	[freq_type] [int] NULL,
	[freq_interval] [int] NULL,
	[freq_subday_type] [int] NULL,
	[freq_subday_interval] [int] NULL,
	[freq_relative_interval] [int] NULL,
	[freq_recurrence_factor] [int] NULL,
	[Status] nvarchar(64) NULL
) ON [PRIMARY]
GO

--Object vw_JobHistory Collects information from JobHistory Table for last reun

CREATE OR ALTER VIEW  [dba].[vw_JobHistory]
AS
WITH History
AS
(
SELECT [CollectionDate] = CONVERT(datetime, 
               SWITCHOFFSET(CONVERT(datetimeoffset, 
                                    [CollectionDate]), 
                            DATENAME(TzOffset, SYSDATETIMEOFFSET()))) 
           ,[Job]
           ,[Server]
           ,[Missing]
           ,[run_date]
           ,[next_run_date]
           ,[JobOwner]
           ,[Job Failed]
           ,[Job Status]
           ,[run_duration]
           ,[Disabled]
           ,[ScheduleDisabled]
           ,[ScheduleInActive]
           ,[freq_sub]
           ,[freq_type]
           ,[freq_interval]
           ,[freq_subday_type]
           ,[freq_subday_interval]
           ,[freq_relative_interval]
           ,[freq_recurrence_factor]
           ,[Status]
		   ,LastRun = row_number() Over(partition by [Server],[Job] order by [CollectionDate] desc)
FROM [dba].[JobHistory])
SELECT h.[CollectionDate]
           ,h.[Job]
           ,h.[Server]
           ,[Missing]
           ,[run_date]
           ,[next_run_date]
           ,[JobOwner]
           ,[Job Failed] = CAST( [Job Failed] as tinyint)
           ,[Job Status]
           ,[run_duration]
           ,[Disabled]
           ,[ScheduleDisabled]
           ,[ScheduleInActive]
           ,[freq_sub]
           ,[freq_type]
           ,[freq_interval]
           ,[freq_subday_type]
           ,[freq_subday_interval]
           ,[freq_relative_interval]
           ,[freq_recurrence_factor]
           ,[Status]
FROM History h
LEFT JOIN [dba].[ExclusionJobs] j on h.[Server] = j.[Server] and h.[Job] = j.Job
WHERE LastRun = 1 and j.[Server] is NULL
GO

IF object_id('dba.BackupStatus') is null 
CREATE TABLE [dba].[BackupStatus](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[dbid] [smallint] NULL,
	[D] [datetime] NULL,
	[I] [datetime] NULL,
	[L] [datetime] NULL,
	[Database] [varchar](60) NULL,
	[BadOwner] [int] NOT NULL,
	[Owner] [nvarchar](128) NULL,
	[MissingFullBackup] [tinyint] NOT NULL,
	[MissingDiffBackup] [tinyint] NOT NULL,
	[MissingLogBackup] [tinyint] NOT NULL,
	[recovery_model_desc] [nvarchar](60) NULL,
	[CollectionDate] [datetime] NULL DEFAULT (getdate()),
	[Server] [nvarchar](60) NULL,
	[LastGoodCheckDbTime] [datetime] NULL,
	[Version] [nvarchar](256) NULL,
	[Build] [nvarchar](50) NULL,
	[Edition] [nvarchar](50) NULL,
	[ProductLevel] [nvarchar](50) NULL,
	[state_desc] [nvarchar](50) NULL DEFAULT 'Unavailable'
	,[DB_State] [tinyint] DEFAULT 0
) ON [PRIMARY]
GO


CREATE OR ALTER   VIEW [dba].[vw_BackupStatus]
AS
WITH LogSpace
AS
(SELECT [Database], [Server], [LogSizeMB], [LogUsed]
,LRN = row_number() OVER(Partition BY  [Server], [Database] ORDER BY CollectionDate DESC)
FROM dba.LOGSPACE
)
SELECT [CollectionDate] = CONVERT(datetime, 
               SWITCHOFFSET(CONVERT(datetimeoffset, 
                                    a.[CollectionDate]), 
                            DATENAME(TzOffset, SYSDATETIMEOFFSET()))) 
      ,a.[Database]
      ,a.[BadOwner]
      ,[MissingFullBackup] = a.[MissingFullBackup] - isnull(ex.[MissingFullBackup],0)
      ,[MissingDiffBackup]= a.[MissingDiffBackup] - isnull(ex.[MissingDiffBackup],0)
      ,[MissingLogBackup]= a.[MissingLogBackup] - isnull(ex.[MissingLogBackup],0)
      ,a.[recovery_model_desc]
	  ,a.[Server]
	  ,[DBCC]= a.[MissingFullBackup] - isnull(ex.[MissingFullBackup],0)
	  ,a.LastGoodCheckDbTime
	  	,a.[Version]
		,a.[Build]
		,a.[ProductLevel]
		,LogSizeMB = round(l.LogSizeMB,2)
		,LogUsed = round(l.LogUsed,2)
		,a.[SQLAgentStatus]
		,state_desc
		,DB_State
FROM (
		SELECT ID, [dbid]
		,[D]
		,[I]
		,[L]
		,[Database]
		,[BadOwner]
		,[Owner]
		,[MissingFullBackup] 
		,[MissingDiffBackup]
		,[MissingLogBackup]
		,[recovery_model_desc]
		,[Server]
		,LastGoodCheckDbTime
		,[DBCC] = CASE WHEN DATEDIFF(dd,LastGoodCheckDbTime,CollectionDate)<7 THEN 0 ELSE 1 END
		,[Version]
		,[Build]
		,[Edition]
		,[ProductLevel]
		,CollectionDate
		,RN = ROW_NUMBER() OVER(PARTITION BY [Server], [Database] ORDER BY CollectionDate DESC)
		,[SQLAgentStatus]
		,state_desc = isnull(state_desc,'Unavailable')
	,DB_State = isnull(DB_State,0)
FROM [dba].[BackupStatus]) a
LEFT JOIN LOGSPACE l on a.[Server] = l.[Server] and a.[Database]=l.[database] AND LRN = 1
LEFT JOIN [dba].[Exclusion_BackupStatus] ex on ex.[Server] = a.[Server] and a.[Database] = ex.[Database]
WHERE RN=1 
GO

CREATE OR ALTER VIEW [dba].[vi_BackupStatus]
AS
SELECT [dbid]
      ,[D]
      ,[I]
      ,[L]
      ,[Database]
      ,[BadOwner]
      ,[Owner]
      ,[MissingFullBackup]
      ,[MissingDiffBackup]
      ,[MissingLogBackup]
      ,[recovery_model_desc]
	  ,CollectionDate
	  ,[Server]
      ,[LastGoodCheckDbTime]
      ,[Version]
      ,[Build]
      ,[Edition]
      ,[ProductLevel]
	  ,SQLAgentStatus
	  ,state_desc
	  ,[DB_State]
FROM [dba].[BackupStatus]
GO

CREATE OR ALTER VIEW
dba.[Servers]
AS
select distinct server_name [Server]
from [msdb].[dbo].[sysmanagement_shared_registered_servers] 
UNION
SELECT @@SERVERNAME;
GO


CREATE OR ALTER VIEW dba.vw_FileSpecs
AS
WITH FS
AS
(
SELECT [Server]
      ,[HostName]
      ,[drivename]
      ,[capacity(GB)]
      ,[freespace(GB)]
      ,[Label]
      ,[Type]
      ,[CollectionDate]
	  ,RN = ROW_NUMBER() OVER(PARTITION BY [Server], [drivename] ORDER BY [CollectionDate] DESC)
  FROM [msdb].[dba].[FileSpecs]
  )
SELECT [Server]
      ,[HostName]
      ,[drivename]
      ,[capacity(GB)]
      ,[freespace(GB)]
      ,[Label]
      ,[Type]
	FROM FS WHERE RN = 1