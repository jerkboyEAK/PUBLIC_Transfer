declare @sql nvarchar(256) = 'CREATE SCHEMA dba'
IF NOT EXISTS(SELECT name from sys.schemas WHERE name='dba')
BEGIN
exec (@sql)
END
GO
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dba].[vw_GetJobDetails]'))
DROP VIEW [dba].[vw_GetJobDetails]
GO
CREATE VIEW [dba].[vw_GetJobDetails]
AS

WITH Details as
(
SELECT [Job] = j.name
      ,ServerName = @@SERVERNAME
	  ,Missing = CASE WHEN j.name is null THEN 1 ELSE 0 END
      ,[run_date] = msdb.dbo.agent_datetime(h.run_date,h.run_time)
     ,[next_run_date] = msdb.dbo.agent_datetime(nullif(js.next_run_date,0), nullif(js.next_run_time,0))
      ,[JobOwner] = suser_sname(j.owner_sid)
	  ,[Job Status] = h.run_status
      ,[run_duration] = h.run_duration
      ,[IsJobDisabled] =  j.[Enabled]^1 
      ,[IsScheduleDisabled] = s.[enabled]^1
      ,[IsScheduleInActive] = CASE WHEN s.active_start_date<s.active_end_date THEN 0 ELSE 1 END
      ,[freq_sub] = s.freq_interval+s.freq_recurrence_factor+s.freq_relative_interval+s.freq_subday_interval+s.freq_subday_type 
	  ,[freq_type] 
	  ,[freq_interval]
      ,[freq_subday_type] 
      ,[freq_subday_interval] 
      ,[freq_relative_interval] 
      ,[freq_recurrence_factor]
	  ,ROW_NUMBER ( ) OVER (PARTITION BY j.name ORDER BY h.run_date DESC, h.run_time desc) RN
	  FROM msdb..sysjobs j 
	  LEFT JOIN msdb..sysjobschedules js on js.job_id=j.job_id
	  LEFT JOIN msdb..sysschedules s on s.schedule_id = js.schedule_id
	  LEFT JOIN [msdb].[dbo].[sysjobhistory] h on j.job_id = h.job_id and step_id = 0
	  WHERE j.category_id = 3
  )

SELECT [CollectionDate] = getutcdate()
	,[Job]
      ,ServerName
      ,[Missing]
      ,[run_date]
      ,[next_run_date]
      ,[JobOwner]
	  ,[Job Failed] = CAST(CASE [Job Status] WHEN 0 THEN 1 ELSE 0 END as TINYINT)
      ,[Job Status]
      ,[run_duration]
      ,[Disabled] = [IsJobDisabled]
      ,ScheduleDisabled = ISNULL([IsScheduleDisabled],1)
      ,ScheduleInActive = ISNULL([IsScheduleInActive],1)
      ,[freq_sub]
      ,[freq_type]
      ,[freq_interval]
      ,[freq_subday_type]
      ,[freq_subday_interval]
      ,[freq_relative_interval]
      ,[freq_recurrence_factor]
	  ,[Status] = CASE WHEN [Job Status] = 0 then 'Failed' WHEN [Job Status] = 1 then 'Succeeded' WHEN [Job Status] = 2 then 'Retry' WHEN [Job Status] = 3 then 'Canceled' WHEN [Job Status] = 4 then 'Retry' else 'Unknown' END
  FROM Details
  WHERE RN = 1
  GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dba].[vw_BACKUP_STATUS]'))
DROP VIEW [dba].vw_BACKUP_STATUS
GO

CREATE VIEW [dba].[vw_BACKUP_STATUS]
AS
WITH BackupSet AS
(
	SELECT dbid,
	  [D], [I], [L]  
	FROM  
	(  SELECT [type]
		, Max(backup_finish_date) backup_finish_date
		,[dbid]
		  from sys.sysdatabases d
		LEFT JOIN msdb..backupset bs on d.name = bs.database_name 
		WHERE dbid<>2
		GROUP BY [type],[dbid]
	) AS SourceTable  
	PIVOT  
	(  
	  Max(backup_finish_date)  
	  FOR [Type] IN ([D], [I], [L])  
	) AS PivotTable 
)

SELECT b.*
	,d.name
	,BadOwner =  case owner_sid when 0x01 then 0 else 1 end 
	,[Owner] = suser_sname(owner_sid)
	,MissingFullBackup = CASE WHEN DATEDIFF(DD, [D],GETDATE())<=7 THEN 0 WHEN sys.fn_hadr_backup_is_preferred_replica(d.name)=0 THEN 0 ELSE 1 END
	,MissingDiffBackup = CASE WHEN (DATEDIFF(hh, [I],GETDATE())<=24 OR (DATEPART(DW,getdate())=2 AND DATEDIFF(hh, [I],GETDATE())<48 ) OR d.database_id<=4) THEN 0 WHEN sys.fn_hadr_backup_is_preferred_replica(d.name)=0 THEN 0  ELSE 1 END
	,MissingLogBackup = CASE WHEN DATEDIFF(MI, [L],GETDATE())<=1 OR d.database_id<=120 OR recovery_model = 3 THEN 0 WHEN sys.fn_hadr_backup_is_preferred_replica(d.name)=0 THEN 0  ELSE 1 END
	,d.recovery_model_desc
	,CollectionDate = GETUTCDATE()
	,ServerName = @@SERVERNAME 
	,LastGoodCheckDbTime = CAST(DATABASEPROPERTYEX(name,'LastGoodCheckDbTime') AS datetime)
	,[Version] = substring(@@VERSION,22,4)
	,[Build] = substring(@@VERSION,28,3) 
	,Edition = CAST(SERVERPROPERTY('Edition') AS VARCHAR(50))
	,ProductLevel = CASE CHARINDEX('CU',@@VERSION,1) WHEN 0 THEN NULL ELSE substring(@@VERSION,CHARINDEX('CU1',@@VERSION,1),4) END
	,SQLAgentStatus = CASE WHEN d.name='msdb' THEN ISNULL((select TOP(1) 1 FROM MASTER.dbo.sysprocesses WHERE program_name like N'SQLAgent%'),0)^1 ELSE 0 END
	,d.state_desc
	,DB_State = CASE d.state WHEN 0 THEN 0 ELSE 1 END
FROM  sys.databases d
LEFT JOIN BackupSet b (nolock) on d.database_id = b.dbid
WHERE dbid<>2;
GO
