select * from sys.dm_hadr_cluster_members
select * from sys.dm_hadr_availability_replica_cluster_nodes where group_name='QUANIN011_AG' order by replica_server_name 
select serverproperty('ComputerNamePhysicalNetBIOS')