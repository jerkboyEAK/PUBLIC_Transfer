SET NOCOUNT ON;
DECLARE @AgentTime datetime
SELECT @AgentTime=MIN(login_time)FROM sys.sysprocesses
select @@servername,service_account
,CAST(serverproperty('IsClustered') as BIT),servicename
,CASE WHEN [status]=4 THEN 0 ELSE 1 END ,substring(@@VERSION,22,4),substring(@@VERSION,CHARINDEX('(',@@VERSION,1)+1,CHARINDEX(')',@@VERSION,1)-CHARINDEX('(',@@VERSION,1)-1),substring(@@VERSION,CHARINDEX('KB',@@VERSION,2),9),CAST(serverproperty('ComputerNamePhysicalNetBIOS') AS NVARCHAR(60)) 
,CAST(isnull(last_startup_time,@AgentTime) as datetime)
from sys.dm_server_services