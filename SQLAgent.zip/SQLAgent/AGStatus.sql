SET NOCOUNT ON;
IF EXISTS(SELECT 1 FROM sys.dm_hadr_database_replica_states where is_local=0)
WITH p as(
select d.name, rs.last_commit_time, rs.replica_id
from sys.dm_hadr_database_replica_states rs
join sys.databases d on d.database_id = rs.database_id
where is_local=1)
,S as (
select d.name, rs.last_commit_time, rs.replica_id
,rs.synchronization_health_desc
from sys.dm_hadr_database_replica_states rs
join sys.databases d on d.database_id = rs.database_id
where is_local=0)
SELECT p.name
,ISNULL(datediff(ss,s.last_commit_time,p.last_commit_time),'') [Delay]
,isnull(p.last_commit_time,'') primary_time ,isnull(s.last_commit_time,'') secondary_time
,sr.replica_server_name [SecondaryServer]
,pr.replica_server_name [PrimaryServer]
,s.synchronization_health_desc
FROM p 
left join s on p.name = s.name
left join sys.availability_replicas AS sr on sr.replica_id = s.replica_id
left join sys.availability_replicas AS pr on pr.replica_id = p.replica_id
