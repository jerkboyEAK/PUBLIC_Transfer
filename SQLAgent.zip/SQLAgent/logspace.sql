SET NOCOUNT ON;
DECLARE
       @dbname VARCHAR(155) = NULL,
       @SpaceUsed FLOAT = NULL;
DECLARE @LOGSPACE TABLE(
       dbName VARCHAR(155),
       LogSizeMB FLOAT,
       [LogSpaceUsed%] FLOAT,
       [Status] INT
       )
INSERT @LOGSPACE
EXEC ('DBCC SQLPERF(''logspace'') with NO_INFOMSGS') ;





SELECT @@servername,dbName,round(LogSizeMB,2),round([LogSpaceUsed%],2),getutcdate()
FROM @LOGSPACE l