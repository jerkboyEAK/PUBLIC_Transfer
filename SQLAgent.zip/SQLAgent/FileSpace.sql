SET NOCOUNT ON
declare @svrName varchar(255)
declare @sql varchar(400)
--by default it will take the current server name, we can the set the server name as well
set @svrName = CAST(SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS VARCHAR(400))
set @sql = 'powershell.exe -c "Get-WmiObject -ComputerName ' + QUOTENAME(@svrName,'''') + ' -Class Win32_Volume -Filter ''DriveType = 3'' | select name,capacity,freespace,Label | foreach{$_.name+''|''+$_.capacity/1048576+''%''+$_.freespace/1048576+''*''+$_.Label+''=^''}"'

DECLARE @Out TABLE(line varchar(255))
--inserting disk name, total space and free space value in to temporary table
insert @Out
EXEC xp_cmdshell @sql
select 
	[ServerName] = @@SERVERNAME
	,[HostName] = CAST(SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS VARCHAR(400))
	,rtrim(ltrim(SUBSTRING(line,1,CHARINDEX('|',line) -1))) as drivename
   ,round(cast(rtrim(ltrim(SUBSTRING(line,CHARINDEX('|',line)+1,
   (CHARINDEX('%',line) -1)-CHARINDEX('|',line)) )) as Float)/1024,0) as 'capacity(GB)'
   ,round(cast(rtrim(ltrim(SUBSTRING(line,CHARINDEX('%',line)+1,
   (CHARINDEX('*',line) -1)-CHARINDEX('%',line)) )) as Float) /1024 ,0)as 'freespace(GB)'
   ,rtrim(ltrim(SUBSTRING(line,CHARINDEX('*',line)+1,
   (CHARINDEX('=',line) -1)-CHARINDEX('*',line)) )) as 'Label'
   ,[Type] = CASE 
			WHEN line like'%database%'OR line  like'%[0-9]_db%' then 'Data'
			WHEN line like'%Temp%Logs%' then 'TempLog'
			WHEN line like'%TempDB%' then 'TempData'
			WHEN line like'%backup%' then 'Backup'
			WHEN line like'%Sys%' then 'System'
			WHEN line like'%Quorum%' then 'Quorum'
			ELSE 'Other'
			END,
			GETUTCDATE() CollectionDate
from @Out
where line like '[E-Z][:]%'
order by drivename
GO